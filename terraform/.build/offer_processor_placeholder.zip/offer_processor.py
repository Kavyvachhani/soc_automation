def handler(event, context):
    print('placeholder — deploy via GitHub Actions')
